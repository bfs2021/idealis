---- MODULE CacheProtocol_TTrace_1795100073 ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CacheProtocol

_expression ==
    LET CacheProtocol_TEExpression == INSTANCE CacheProtocol_TEExpression
    IN CacheProtocol_TEExpression!expression
----

_trace ==
    LET CacheProtocol_TETrace == INSTANCE CacheProtocol_TETrace
    IN CacheProtocol_TETrace!trace
----

_inv ==
    ~(
        TLCGet("level") = Len(_TETrace)
        /\
        bad = ()
        /\
        tokens = ({[owner |-> "w1", fence |-> 1], [owner |-> "w1", fence |-> 2]})
        /\
        clock = (0)
        /\
        event = ([op |-> "publish", owner |-> "w1", fence |-> 1, complete |-> TRUE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> "a"])
        /\
        cell = ([owner |-> "", fence |-> 2, complete |-> TRUE, identity |-> "a", phase |-> "ready", expiresAt |-> 0, storedIdentity |-> "a"])
    )
----

_init ==
    /\ bad = _TETrace[1].bad
    /\ event = _TETrace[1].event
    /\ tokens = _TETrace[1].tokens
    /\ cell = _TETrace[1].cell
    /\ clock = _TETrace[1].clock
----

_next ==
    /\ \E i,j \in DOMAIN _TETrace:
        /\ \/ /\ j = i + 1
              /\ i = TLCGet("level")
        /\ bad  = _TETrace[i].bad
        /\ bad' = _TETrace[j].bad
        /\ event  = _TETrace[i].event
        /\ event' = _TETrace[j].event
        /\ tokens  = _TETrace[i].tokens
        /\ tokens' = _TETrace[j].tokens
        /\ cell  = _TETrace[i].cell
        /\ cell' = _TETrace[j].cell
        /\ clock  = _TETrace[i].clock
        /\ clock' = _TETrace[j].clock

\* Uncomment the ASSUME below to write the states of the error trace
\* to the given file in Json format. Note that you can pass any tuple
\* to `JsonSerialize`. For example, a sub-sequence of _TETrace.
    \* ASSUME
    \*     LET J == INSTANCE Json
    \*         IN J!JsonSerialize("CacheProtocol_TTrace_1795100073.json", _TETrace)

=============================================================================

 Note that you can extract this module `CacheProtocol_TEExpression`
  to a dedicated file to reuse `expression` (the module in the 
  dedicated `CacheProtocol_TEExpression.tla` file takes precedence 
  over the module `CacheProtocol_TEExpression` below).

---- MODULE CacheProtocol_TEExpression ----
EXTENDS Sequences, TLCExt, Toolbox, Naturals, TLC, CacheProtocol

expression == 
    [
        \* To hide variables of the `CacheProtocol` spec from the error trace,
        \* remove the variables below.  The trace will be written in the order
        \* of the fields of this record.
        bad |-> bad
        ,event |-> event
        ,tokens |-> tokens
        ,cell |-> cell
        ,clock |-> clock
        
        \* Put additional constant-, state-, and action-level expressions here:
        \* ,_stateNumber |-> _TEPosition
        \* ,_badUnchanged |-> bad = bad'
        
        \* Format the `bad` variable as Json value.
        \* ,_badJson |->
        \*     LET J == INSTANCE Json
        \*     IN J!ToJson(bad)
        
        \* Lastly, you may build expressions over arbitrary sets of states by
        \* leveraging the _TETrace operator.  For example, this is how to
        \* count the number of times a spec variable changed up to the current
        \* state in the trace.
        \* ,_badModCount |->
        \*     LET F[s \in DOMAIN _TETrace] ==
        \*         IF s = 1 THEN 0
        \*         ELSE IF _TETrace[s].bad # _TETrace[s-1].bad
        \*             THEN 1 + F[s-1] ELSE F[s-1]
        \*     IN F[_TEPosition - 1]
    ]

=============================================================================



Parsing and semantic processing can take forever if the trace below is long.
 In this case, it is advised to uncomment the module below to deserialize the
 trace from a generated binary file.

\*
\*---- MODULE CacheProtocol_TETrace ----
\*EXTENDS IOUtils, TLC, CacheProtocol
\*
\*trace == IODeserialize("CacheProtocol_TTrace_1795100073.bin", TRUE)
\*
\*=============================================================================
\*

---- MODULE CacheProtocol_TETrace ----
EXTENDS TLC, CacheProtocol

trace == 
    <<
    ([bad |-> FALSE,tokens |-> {},clock |-> 0,event |-> [op |-> "init", owner |-> "", fence |-> 0, complete |-> FALSE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> ""],cell |-> [owner |-> "", fence |-> 0, complete |-> FALSE, identity |-> "a", phase |-> "idle", expiresAt |-> 0, storedIdentity |-> ""]]),
    ([bad |-> FALSE,tokens |-> {[owner |-> "w1", fence |-> 1]},clock |-> 0,event |-> [op |-> "acquire", owner |-> "w1", fence |-> 0, complete |-> FALSE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> ""],cell |-> [owner |-> "w1", fence |-> 1, complete |-> FALSE, identity |-> "a", phase |-> "leased", expiresAt |-> 2, storedIdentity |-> ""]]),
    ([bad |-> FALSE,tokens |-> {[owner |-> "w1", fence |-> 1]},clock |-> 0,event |-> [op |-> "release", owner |-> "w1", fence |-> 1, complete |-> FALSE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> ""],cell |-> [owner |-> "", fence |-> 1, complete |-> FALSE, identity |-> "a", phase |-> "idle", expiresAt |-> 0, storedIdentity |-> ""]]),
    ([bad |-> FALSE,tokens |-> {[owner |-> "w1", fence |-> 1], [owner |-> "w1", fence |-> 2]},clock |-> 0,event |-> [op |-> "acquire", owner |-> "w1", fence |-> 0, complete |-> FALSE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> ""],cell |-> [owner |-> "w1", fence |-> 2, complete |-> FALSE, identity |-> "a", phase |-> "leased", expiresAt |-> 2, storedIdentity |-> ""]]),
    ([bad |-> ,tokens |-> {[owner |-> "w1", fence |-> 1], [owner |-> "w1", fence |-> 2]},clock |-> 0,event |-> [op |-> "publish", owner |-> "w1", fence |-> 1, complete |-> TRUE, identity |-> "a", now |-> 0, duration |-> 2, receiptIdentity |-> "a"],cell |-> [owner |-> "", fence |-> 2, complete |-> TRUE, identity |-> "a", phase |-> "ready", expiresAt |-> 0, storedIdentity |-> "a"]])
    >>
----


=============================================================================

---- CONFIG CacheProtocol_TTrace_1795100073 ----
CONSTANTS
    Broken = 1

INVARIANT
    _inv

CHECK_DEADLOCK
    \* CHECK_DEADLOCK off because of PROPERTY or INVARIANT above.
    FALSE

INIT
    _init

NEXT
    _next

CONSTANT
    _TETrace <- _trace

ALIAS
    _expression
=============================================================================
\* Generated on Thu Nov 19 23:54:33 JST 2026