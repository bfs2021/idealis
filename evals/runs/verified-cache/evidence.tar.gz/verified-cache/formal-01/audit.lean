import Cache
#print axioms Cache.initial_valid
#print axioms Cache.step_valid
#print axioms Cache.step_identity
#print axioms Cache.step_fence_monotone
#print axioms Cache.expired_publish
#print axioms Cache.stale_fence_publish
#print axioms Cache.wrong_receipt_not_published
#print axioms Cache.incomplete_not_published
#print axioms Cache.current_complete_publishes
#print axioms Cache.renewed_fence
#print axioms Cache.foreign_owner_publish
#print axioms Cache.acquired_fence
#print axioms Cache.cache_hit_reachable
#print axioms Cache.trace_valid
#print axioms Cache.trace_fence_monotone
#print axioms Cache.closed_graph_covers
#print axioms Cache.cached_graph_safe
