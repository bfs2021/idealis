---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
Init == x=0
Next == UNCHANGED <<>> /\ x'=IF x=0 THEN 1 ELSE 1
Spec == Init /\ [][Next]_x
Safe == x<=1
====