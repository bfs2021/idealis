---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
V0 == x
V1 == <<V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0>>
V2 == <<V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1>>
V3 == <<V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2>>
Init == x=0
Next == x'=x
Spec == Init /\ [][Next]_V3
Safe == x=0
====