import {writeFile} from 'node:fs/promises';
import {runTypeScript, runNative, mebibytes} from '../../dist/evals/tlc-differential/operator-sharing-support.js';
const definitions = (depth,width) => ['V0 == x', ...Array.from({length:depth},(_,i)=>`V${i+1} == <<${Array(width).fill(`V${i}`).join(',')}>>`)].join('\n');
const results=[];
for(const [depth,width] of [[3,8],[6,16]]) {
 const input={source:`---- MODULE Wide ----\nEXTENDS Naturals\nVARIABLE x\n${definitions(depth,width)}\nInit == x=0\nNext == x'=x\nSpec == Init /\\ [][Next]_V${depth}\n====`,config:'SPECIFICATION Spec\nCHECK_DEADLOCK FALSE',irVersion:2};
 const bounds={maxDepth:8,maxStates:100,maxWork:100000};
 for(const backend of ['ts','rust']) {
  try {
   const measured=backend==='ts'?await runTypeScript(input,bounds,{milliseconds:30000,bytes:mebibytes(512)}):await runNative({kind:'check-tla',...input,bounds},{milliseconds:30000,bytes:mebibytes(512)});
   results.push({depth,width,backend,measured});
  }catch(error){results.push({depth,width,backend,error:error.stack});}
  await writeFile('.artifacts/pr62-review/wide-target-red.json',JSON.stringify(results,null,2)+'\n');
  console.log(depth,width,backend,results.at(-1).error?.split('\n')[0]??results.at(-1).measured.outcome);
 }
}
