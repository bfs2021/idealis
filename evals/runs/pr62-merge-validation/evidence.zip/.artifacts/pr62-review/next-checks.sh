set -e
just package > .artifacts/pr62-review/package-1.log 2>&1
just evaluate > .artifacts/pr62-review/evaluate-1.log 2>&1
just replay-evaluation > .artifacts/pr62-review/replay-evaluation-1.log 2>&1
just eval-loop > .artifacts/pr62-review/eval-loop-1.log 2>&1
just replay-loop > .artifacts/pr62-review/replay-loop-1.log 2>&1
