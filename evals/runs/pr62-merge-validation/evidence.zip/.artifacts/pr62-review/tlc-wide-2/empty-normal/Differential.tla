---- MODULE Differential ----
EXTENDS Naturals
VARIABLE x
V0 == <<>>
V1 == <<V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0,V0>>
V2 == <<V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1,V1>>
V3 == <<V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2,V2>>
Init == x=0
Next == UNCHANGED V3 /\ x'=IF x=0 THEN 1 ELSE 1
Spec == Init /\ [][Next]_x
Safe == x<=1
====